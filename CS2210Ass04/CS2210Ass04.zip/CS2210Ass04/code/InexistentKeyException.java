
public class InexistentKeyException extends RuntimeException{
	
	public InexistentKeyException() {
		super("Key does not exist");
	}
}
