
public class EmptyTreeException extends RuntimeException{
	
	public EmptyTreeException() {
		super("Empty tree");
	}
}
