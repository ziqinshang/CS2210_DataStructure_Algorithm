
public class DuplicatedKeyException extends RuntimeException {
	
	public DuplicatedKeyException() {
		super("Duplicated Key");
	}
}
